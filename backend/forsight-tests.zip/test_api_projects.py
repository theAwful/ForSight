"""
Integration tests for projects API:
  POST   /api/projects
  GET    /api/projects
  GET    /api/projects/{id}
  DELETE /api/projects/{id}
  POST   /api/projects/{id}/roe/paste
  PUT    /api/projects/{id}/targets
  GET    /api/projects/{id}/targets
  GET    /api/projects/{id}/nmap-ready
"""

import pytest
import json
import io


class TestCreateProject:

    def test_creates_project(self, client):
        resp = client.post("/api/projects", json={"name": "My Engagement"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "My Engagement"
        assert "id" in data
        assert data["id"] > 0

    def test_creates_checklist_status(self, client):
        resp = client.post("/api/projects", json={"name": "Check Eng"})
        pid = resp.json()["id"]
        cl = client.get(f"/api/projects/{pid}/checklist")
        assert cl.status_code == 200
        phases = cl.json()
        assert len(phases) > 0

    def test_empty_name_allowed(self, client):
        # FastAPI + pydantic will accept "" since it's a str; app doesn't enforce non-empty
        resp = client.post("/api/projects", json={"name": ""})
        assert resp.status_code in (200, 422)

    def test_missing_name_returns_422(self, client):
        resp = client.post("/api/projects", json={})
        assert resp.status_code == 422

    def test_targets_summary_none_initially(self, client):
        resp = client.post("/api/projects", json={"name": "Fresh"})
        assert resp.json()["targets_summary"] is None


class TestListProjects:

    def test_returns_list(self, client):
        resp = client.get("/api/projects")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_lists_created_project(self, client, project):
        resp = client.get("/api/projects")
        ids = [p["id"] for p in resp.json()]
        assert project["id"] in ids

    def test_ordered_newest_first(self, client):
        p1 = client.post("/api/projects", json={"name": "First"}).json()
        p2 = client.post("/api/projects", json={"name": "Second"}).json()
        resp = client.get("/api/projects")
        ids = [p["id"] for p in resp.json()]
        assert ids.index(p2["id"]) < ids.index(p1["id"])


class TestGetProject:

    def test_get_existing_project(self, client, project):
        resp = client.get(f"/api/projects/{project['id']}")
        assert resp.status_code == 200
        assert resp.json()["id"] == project["id"]

    def test_get_nonexistent_returns_404(self, client):
        resp = client.get("/api/projects/99999")
        assert resp.status_code == 404

    def test_includes_targets_summary_after_roe(self, client, project_with_targets):
        pid = project_with_targets["id"]
        resp = client.get(f"/api/projects/{pid}")
        summary = resp.json()["targets_summary"]
        assert summary is not None
        assert summary["ips"] >= 0
        assert summary["domains"] >= 0


class TestDeleteProject:

    def test_deletes_project(self, client, project):
        pid = project["id"]
        resp = client.delete(f"/api/projects/{pid}")
        assert resp.status_code == 200
        assert resp.json()["deleted"] == pid
        # Confirm it's gone
        assert client.get(f"/api/projects/{pid}").status_code == 404

    def test_delete_nonexistent_returns_404(self, client):
        resp = client.delete("/api/projects/99999")
        assert resp.status_code == 404


class TestPasteROE:

    def test_paste_ips_and_domains(self, client, project):
        pid = project["id"]
        resp = client.post(
            f"/api/projects/{pid}/roe/paste",
            json={"content": "192.168.1.1\n10.0.0.1\nexample.com"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ips_count"] == 2
        assert data["domains_count"] == 1

    def test_paste_only_ips(self, client, project):
        pid = project["id"]
        resp = client.post(
            f"/api/projects/{pid}/roe/paste",
            json={"content": "10.10.10.1\n10.10.10.2\n10.10.10.3"},
        )
        assert resp.status_code == 200
        assert resp.json()["ips_count"] == 3
        assert resp.json()["domains_count"] == 0

    def test_paste_updates_targets_summary(self, client, project):
        pid = project["id"]
        client.post(
            f"/api/projects/{pid}/roe/paste",
            json={"content": "192.168.1.1\nexample.com"},
        )
        p = client.get(f"/api/projects/{pid}").json()
        assert p["targets_summary"]["ips"] == 1
        assert p["targets_summary"]["domains"] == 1

    def test_paste_nonexistent_project_404(self, client):
        resp = client.post(
            "/api/projects/99999/roe/paste",
            json={"content": "192.168.1.1"},
        )
        assert resp.status_code == 404

    def test_sanitizes_script_tags(self, client, project):
        pid = project["id"]
        resp = client.post(
            f"/api/projects/{pid}/roe/paste",
            json={"content": '<script>alert("xss")</script>192.168.1.1'},
        )
        assert resp.status_code == 200
        assert resp.json()["ips_count"] == 1

    def test_empty_content_returns_zero_targets(self, client, project):
        pid = project["id"]
        resp = client.post(
            f"/api/projects/{pid}/roe/paste",
            json={"content": ""},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ips_count"] == 0
        assert data["domains_count"] == 0


class TestGetTargets:

    def test_returns_targets(self, client, project_with_targets):
        pid = project_with_targets["id"]
        resp = client.get(f"/api/projects/{pid}/targets")
        assert resp.status_code == 200
        data = resp.json()
        assert "ips" in data
        assert "domains" in data
        assert "192.168.1.1" in data["ips"]
        assert "example.com" in data["domains"]

    def test_empty_before_roe(self, client, project):
        pid = project["id"]
        resp = client.get(f"/api/projects/{pid}/targets")
        assert resp.status_code == 200
        data = resp.json()
        assert data["ips"] == []
        assert data["domains"] == []


class TestUpdateTargets:

    def test_update_targets(self, client, project):
        pid = project["id"]
        resp = client.put(
            f"/api/projects/{pid}/targets",
            json={"content": "172.16.0.1\nnewdomain.com"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ips_count"] == 1
        assert data["domains_count"] == 1

    def test_update_replaces_previous_targets(self, client, project_with_targets):
        pid = project_with_targets["id"]
        client.put(
            f"/api/projects/{pid}/targets",
            json={"content": "172.16.0.1"},
        )
        targets = client.get(f"/api/projects/{pid}/targets").json()
        assert "172.16.0.1" in targets["ips"]
        # Old targets should be gone
        assert "192.168.1.1" not in targets["ips"]


class TestNmapReady:

    def test_nmap_not_ready_initially(self, client, project):
        pid = project["id"]
        resp = client.get(f"/api/projects/{pid}/nmap-ready")
        assert resp.status_code == 200
        assert resp.json()["nmap_done"] is False

    def test_nonexistent_project_404(self, client):
        resp = client.get("/api/projects/99999/nmap-ready")
        assert resp.status_code == 404


class TestUploadROE:

    def test_upload_txt_file(self, client, project):
        pid = project["id"]
        content = b"192.168.1.1\nexample.com\n"
        resp = client.post(
            f"/api/projects/{pid}/roe",
            files={"file": ("scope.txt", io.BytesIO(content), "text/plain")},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ips_count"] == 1
        assert data["domains_count"] == 1
        assert data["filename"] == "scope.txt"

    def test_upload_csv_file(self, client, project):
        pid = project["id"]
        content = b"ip\n10.0.0.1\n10.0.0.2\n"
        resp = client.post(
            f"/api/projects/{pid}/roe",
            files={"file": ("scope.csv", io.BytesIO(content), "text/csv")},
        )
        assert resp.status_code == 200
        assert resp.json()["ips_count"] == 2
