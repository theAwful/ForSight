"""
Unit tests for app.roe — ROE parsing and input sanitization.

Covers: parse_txt, parse_csv, parse_json, parse_roe_content, sanitize_roe_input
"""

import pytest

from app.roe import (
    parse_txt,
    parse_csv,
    parse_json,
    parse_roe_content,
    sanitize_roe_input,
    ROE_PASTE_MAX_LENGTH,
)


# ---------------------------------------------------------------------------
# sanitize_roe_input
# ---------------------------------------------------------------------------

class TestSanitizeRoeInput:

    def test_empty_string(self):
        assert sanitize_roe_input("") == ""

    def test_none_returns_empty(self):
        assert sanitize_roe_input(None) == ""

    def test_non_string_returns_empty(self):
        assert sanitize_roe_input(42) == ""

    def test_normal_ips_unchanged(self):
        content = "192.168.1.1\n10.0.0.1"
        assert sanitize_roe_input(content) == content

    def test_strips_script_tags(self):
        content = '<script>alert("xss")</script>192.168.1.1'
        result = sanitize_roe_input(content)
        assert "<script>" not in result
        assert "alert" not in result
        assert "192.168.1.1" in result

    def test_strips_style_tags(self):
        content = "<style>body{color:red}</style>example.com"
        result = sanitize_roe_input(content)
        assert "<style>" not in result
        assert "example.com" in result

    def test_strips_arbitrary_html_tags(self):
        content = "<b>192.168.1.1</b>"
        result = sanitize_roe_input(content)
        assert "<b>" not in result
        assert "192.168.1.1" in result

    def test_removes_null_bytes(self):
        content = "192.168.1.1\x00evil"
        result = sanitize_roe_input(content)
        assert "\x00" not in result

    def test_truncates_at_max_length(self):
        long_content = "A" * (ROE_PASTE_MAX_LENGTH + 1000)
        result = sanitize_roe_input(long_content)
        assert len(result) <= ROE_PASTE_MAX_LENGTH

    def test_preserves_newlines_and_tabs(self):
        content = "192.168.1.1\nexample.com\t# comment"
        result = sanitize_roe_input(content)
        assert "\n" in result
        assert "\t" in result

    def test_strips_leading_trailing_whitespace(self):
        result = sanitize_roe_input("  192.168.1.1  ")
        assert result == "192.168.1.1"


# ---------------------------------------------------------------------------
# parse_txt
# ---------------------------------------------------------------------------

class TestParseTxt:

    def test_empty(self):
        ips, domains = parse_txt("")
        assert ips == [] and domains == []

    def test_single_ip(self):
        ips, domains = parse_txt("192.168.1.1")
        assert ips == ["192.168.1.1"]
        assert domains == []

    def test_single_domain(self):
        ips, domains = parse_txt("example.com")
        assert ips == []
        assert domains == ["example.com"]

    def test_mixed(self):
        content = "192.168.1.1\nexample.com\n10.0.0.0/24"
        ips, domains = parse_txt(content)
        assert "192.168.1.1" in ips
        assert "10.0.0.0/24" in ips
        assert "example.com" in domains

    def test_comments_skipped(self):
        content = "# This is a comment\n192.168.1.1"
        ips, domains = parse_txt(content)
        assert ips == ["192.168.1.1"]
        assert domains == []

    def test_blank_lines_skipped(self):
        content = "192.168.1.1\n\n\nexample.com"
        ips, domains = parse_txt(content)
        assert len(ips) == 1
        assert len(domains) == 1

    def test_quoted_values_stripped(self):
        content = '"192.168.1.1"\n\'example.com\''
        ips, domains = parse_txt(content)
        assert "192.168.1.1" in ips
        assert "example.com" in domains

    def test_cidr_notation(self):
        ips, domains = parse_txt("10.0.0.0/8")
        assert "10.0.0.0/8" in ips

    def test_whitespace_only_lines_skipped(self):
        ips, domains = parse_txt("   \n  \t  \n192.168.1.1")
        assert ips == ["192.168.1.1"]


# ---------------------------------------------------------------------------
# parse_csv
# ---------------------------------------------------------------------------

class TestParseCsv:

    def test_ip_column(self):
        content = "ip,name\n192.168.1.1,server1\n10.0.0.1,server2"
        ips, domains = parse_csv(content)
        assert "192.168.1.1" in ips
        assert "10.0.0.1" in ips

    def test_domain_column(self):
        content = "domain,type\nexample.com,external\ntest.example.com,internal"
        ips, domains = parse_csv(content)
        assert "example.com" in domains
        assert "test.example.com" in domains

    def test_target_column(self):
        content = "target\n192.168.1.1\nexample.com"
        ips, domains = parse_csv(content)
        assert "192.168.1.1" in ips
        assert "example.com" in domains

    def test_host_column(self):
        content = "host\n10.10.10.1\nservice.local"
        ips, domains = parse_csv(content)
        assert "10.10.10.1" in ips

    def test_fallback_to_first_column(self):
        content = "value,irrelevant\n172.16.0.1,x\nexample.org,y"
        ips, domains = parse_csv(content)
        assert "172.16.0.1" in ips
        assert "example.org" in domains

    def test_empty_content(self):
        ips, domains = parse_csv("")
        assert ips == [] and domains == []

    def test_malformed_csv_falls_back_to_txt(self):
        content = "192.168.1.1\nexample.com"  # no CSV headers
        ips, domains = parse_csv(content)
        # Should still parse something
        assert len(ips) + len(domains) > 0


# ---------------------------------------------------------------------------
# parse_json
# ---------------------------------------------------------------------------

class TestParseJson:

    def test_list_of_mixed(self):
        content = '["192.168.1.1", "example.com", "10.0.0.1"]'
        ips, domains = parse_json(content)
        assert "192.168.1.1" in ips
        assert "10.0.0.1" in ips
        assert "example.com" in domains

    def test_dict_with_ips_and_domains(self):
        content = '{"ips": ["192.168.1.1"], "domains": ["example.com"]}'
        ips, domains = parse_json(content)
        assert ips == ["192.168.1.1"]
        assert domains == ["example.com"]

    def test_dict_with_singular_keys(self):
        content = '{"ip": ["10.0.0.1"], "domain": ["test.com"]}'
        ips, domains = parse_json(content)
        assert "10.0.0.1" in ips
        assert "test.com" in domains

    def test_invalid_json_fallback_to_txt(self):
        content = "192.168.1.1\nexample.com"
        ips, domains = parse_json(content)
        # Falls back to parse_txt
        assert len(ips) + len(domains) > 0

    def test_empty_lists(self):
        content = '{"ips": [], "domains": []}'
        ips, domains = parse_json(content)
        assert ips == [] and domains == []


# ---------------------------------------------------------------------------
# parse_roe_content — dispatch by extension
# ---------------------------------------------------------------------------

class TestParseRoeContent:

    def test_txt_extension(self):
        ips, domains = parse_roe_content("192.168.1.1\nexample.com", "scope.txt")
        assert "192.168.1.1" in ips

    def test_csv_extension(self):
        content = "ip\n192.168.1.1"
        ips, domains = parse_roe_content(content, "scope.csv")
        assert "192.168.1.1" in ips

    def test_json_extension(self):
        content = '["192.168.1.1"]'
        ips, domains = parse_roe_content(content, "scope.json")
        assert "192.168.1.1" in ips

    def test_no_extension_falls_back_to_txt(self):
        ips, domains = parse_roe_content("192.168.1.1", "noext")
        assert "192.168.1.1" in ips

    def test_uppercase_extension(self):
        # Extension handling is case-insensitive via .lower()
        ips, domains = parse_roe_content('["192.168.1.1"]', "scope.JSON")
        assert "192.168.1.1" in ips

    def test_mixed_ips_and_domains(self):
        content = "10.10.10.1\n10.10.10.2\napp.example.com\nwww.example.com"
        ips, domains = parse_roe_content(content, "targets.txt")
        assert len(ips) == 2
        assert len(domains) == 2
