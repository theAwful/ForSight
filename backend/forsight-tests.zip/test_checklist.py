"""
Unit tests for app.checklist — checklist definition and helpers.
"""

import pytest

from app.checklist import (
    CHECKLIST,
    Phase,
    PRE_ENGAGEMENT_GATE_ITEM_IDS,
    PHASES_REQUIRING_NMAP,
    ChecklistItem,
    get_checklist_by_phase,
    get_item,
    get_item_id_by_runner_key,
    get_runner_keys_for_phase,
)


class TestChecklistDefinition:

    def test_checklist_not_empty(self):
        assert len(CHECKLIST) > 0

    def test_all_items_have_ids(self):
        for item in CHECKLIST:
            assert item.id, f"Item missing id: {item}"

    def test_all_ids_unique(self):
        ids = [item.id for item in CHECKLIST]
        assert len(ids) == len(set(ids)), "Duplicate checklist item IDs"

    def test_all_items_have_phase(self):
        for item in CHECKLIST:
            assert isinstance(item.phase, Phase)

    def test_all_items_have_description(self):
        for item in CHECKLIST:
            assert item.description

    def test_pre_engagement_gate_items_exist(self):
        ids = {item.id for item in CHECKLIST}
        for gate_id in PRE_ENGAGEMENT_GATE_ITEM_IDS:
            assert gate_id in ids, f"Gate item {gate_id} not in checklist"

    def test_phases_requiring_nmap_are_valid(self):
        for phase in PHASES_REQUIRING_NMAP:
            assert isinstance(phase, Phase)

    def test_runner_keys_are_unique_if_set(self):
        keys = [item.runner_key for item in CHECKLIST if item.runner_key]
        assert len(keys) == len(set(keys)), "Duplicate runner keys"


class TestGetChecklistByPhase:

    def test_returns_dict(self):
        result = get_checklist_by_phase()
        assert isinstance(result, dict)

    def test_all_phases_present(self):
        # Reporting phase has no checklist items currently, so skip it
        result = get_checklist_by_phase()
        phases_with_items = {i.phase for i in CHECKLIST}
        for phase in Phase:
            if phase not in phases_with_items:
                continue
            assert phase.value in result, f"Phase {phase.value} missing"

    def test_each_phase_has_items(self):
        result = get_checklist_by_phase()
        for phase, items in result.items():
            assert isinstance(items, list)
            assert len(items) > 0, f"Phase {phase} has no items"

    def test_items_have_required_keys(self):
        result = get_checklist_by_phase()
        for phase, items in result.items():
            for item in items:
                assert "id" in item
                assert "description" in item
                assert "runner_key" in item
                assert "tools" in item


class TestGetItem:

    def test_finds_existing_item(self):
        item = get_item("roe_scope")
        assert item is not None
        assert item.id == "roe_scope"
        assert item.phase == Phase.PRE_ENGAGEMENT

    def test_returns_none_for_missing(self):
        assert get_item("nonexistent_item") is None

    def test_returns_none_for_empty_string(self):
        assert get_item("") is None


class TestGetItemIdByRunnerKey:

    def test_finds_runner_key(self):
        # nmap_ports is a known runner key
        item_id = get_item_id_by_runner_key("nmap_ports")
        assert item_id is not None
        assert item_id == "enum_nmap_tcp_udp"

    def test_returns_none_for_unknown_key(self):
        assert get_item_id_by_runner_key("no_such_runner") is None

    def test_recon_subfinder(self):
        item_id = get_item_id_by_runner_key("recon_subfinder")
        assert item_id == "recon_subfinder"


class TestGetRunnerKeysForPhase:

    def test_nmap_phase_has_runners(self):
        keys = get_runner_keys_for_phase(Phase.NMAP)
        assert len(keys) > 0
        assert "nmap_ports" in keys

    def test_recon_phase_has_multiple_runners(self):
        keys = get_runner_keys_for_phase(Phase.RECON)
        assert len(keys) >= 3

    def test_pre_engagement_no_runners(self):
        keys = get_runner_keys_for_phase(Phase.PRE_ENGAGEMENT)
        # Pre-engagement items have no runner_key (manual steps)
        assert keys == []

    def test_returns_list(self):
        keys = get_runner_keys_for_phase(Phase.WEB_HOST)
        assert isinstance(keys, list)
