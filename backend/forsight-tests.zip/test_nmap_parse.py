"""
Unit tests for app.nmap_parse — nmap output parsing utilities.
"""

import pytest
from pathlib import Path


NMAP_PORTS_OUTPUT = """\
Starting Nmap 7.94 ( https://nmap.org )
Nmap scan report for 192.168.1.1
Host is up (0.001s latency).

22/tcp   open  ssh
80/tcp   open  http
443/tcp  open  https
8080/tcp open  http-proxy

Nmap scan report for 10.0.0.5
Host is up.
21/tcp  open  ftp
3306/tcp open  mysql
"""

NMAP_SERVICES_OUTPUT = """\
Nmap scan report for 192.168.1.100
Host is up.
22/tcp  open  ssh     OpenSSH 8.4p1 Debian
80/tcp  open  http    Apache httpd 2.4.41
443/tcp open  ssl/http nginx 1.20.1
"""


@pytest.fixture
def results_dir(tmp_path):
    return tmp_path


@pytest.fixture
def results_with_ports(tmp_path):
    (tmp_path / "nmap_ports.txt").write_text(NMAP_PORTS_OUTPUT)
    return tmp_path


@pytest.fixture
def results_with_services(tmp_path):
    (tmp_path / "nmap_services.txt").write_text(NMAP_SERVICES_OUTPUT)
    return tmp_path


class TestGetPortsByHost:
    from app.nmap_parse import get_ports_by_host

    def test_parses_basic_ports(self, results_with_ports):
        from app.nmap_parse import get_ports_by_host
        result = get_ports_by_host(results_with_ports)
        assert 22 in result["192.168.1.1"]
        assert 80 in result["192.168.1.1"]
        assert 443 in result["192.168.1.1"]
        assert 8080 in result["192.168.1.1"]

    def test_multiple_hosts(self, results_with_ports):
        from app.nmap_parse import get_ports_by_host
        result = get_ports_by_host(results_with_ports)
        assert "192.168.1.1" in result
        assert "10.0.0.5" in result
        assert 21 in result["10.0.0.5"]
        assert 3306 in result["10.0.0.5"]

    def test_ports_sorted(self, results_with_ports):
        from app.nmap_parse import get_ports_by_host
        result = get_ports_by_host(results_with_ports)
        ports = result["192.168.1.1"]
        assert ports == sorted(ports)

    def test_empty_directory(self, results_dir):
        from app.nmap_parse import get_ports_by_host
        result = get_ports_by_host(results_dir)
        assert result == {}

    def test_no_duplicate_ports(self, tmp_path):
        from app.nmap_parse import get_ports_by_host
        content = (
            "Nmap scan report for 10.0.0.1\n"
            "80/tcp open http\n"
        )
        # Write same host twice in two files
        (tmp_path / "nmap_ports.txt").write_text(content)
        (tmp_path / "nmap_services.txt").write_text(content)
        result = get_ports_by_host(tmp_path)
        assert result["10.0.0.1"].count(80) == 1


class TestNmapOutputExists:

    def test_returns_true_for_ports_file(self, tmp_path):
        from app.nmap_parse import nmap_output_exists
        (tmp_path / "nmap_ports.txt").write_text("content")
        assert nmap_output_exists(tmp_path) is True

    def test_returns_true_for_services_file(self, tmp_path):
        from app.nmap_parse import nmap_output_exists
        (tmp_path / "nmap_services.txt").write_text("content")
        assert nmap_output_exists(tmp_path) is True

    def test_returns_false_when_no_files(self, tmp_path):
        from app.nmap_parse import nmap_output_exists
        assert nmap_output_exists(tmp_path) is False

    def test_returns_false_for_nonexistent_dir(self, tmp_path):
        from app.nmap_parse import nmap_output_exists
        assert nmap_output_exists(tmp_path / "nonexistent") is False


class TestGetHostsForPorts:

    def test_finds_hosts_with_matching_port(self, results_with_ports):
        from app.nmap_parse import get_hosts_for_ports
        result = get_hosts_for_ports(results_with_ports, [80])
        assert "192.168.1.1:80" in result

    def test_finds_multiple_ports(self, results_with_ports):
        from app.nmap_parse import get_hosts_for_ports
        result = get_hosts_for_ports(results_with_ports, [22, 443])
        assert "192.168.1.1:22" in result
        assert "192.168.1.1:443" in result

    def test_empty_when_no_match(self, results_with_ports):
        from app.nmap_parse import get_hosts_for_ports
        result = get_hosts_for_ports(results_with_ports, [9999])
        assert result == []

    def test_empty_directory(self, results_dir):
        from app.nmap_parse import get_hosts_for_ports
        result = get_hosts_for_ports(results_dir, [80])
        assert result == []


class TestGetPortsWithVersions:

    def test_parses_service_and_product(self, results_with_services):
        from app.nmap_parse import get_ports_with_versions
        result = get_ports_with_versions(results_with_services)
        host = result["192.168.1.100"]
        ports_map = {p["port"]: p for p in host}
        assert 22 in ports_map
        assert ports_map[80]["service"] == "http"
        assert "Apache" in (ports_map[80]["product"] or "")

    def test_ports_sorted_by_port_num(self, results_with_services):
        from app.nmap_parse import get_ports_with_versions
        result = get_ports_with_versions(results_with_services)
        for host, ports in result.items():
            nums = [p["port"] for p in ports]
            assert nums == sorted(nums)

    def test_fallback_when_no_services_file(self, results_with_ports):
        from app.nmap_parse import get_ports_with_versions
        # Only nmap_ports.txt exists — no version info
        result = get_ports_with_versions(results_with_ports)
        assert "192.168.1.1" in result
        for p in result["192.168.1.1"]:
            assert p["service"] is None

    def test_empty_dir_returns_empty(self, results_dir):
        from app.nmap_parse import get_ports_with_versions
        result = get_ports_with_versions(results_dir)
        assert result == {}
