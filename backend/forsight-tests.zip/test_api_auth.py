"""
Integration tests for auth API endpoints:
  POST /api/auth/login
  POST /api/auth/logout
  GET  /api/auth/me
"""

import pytest
from fastapi.testclient import TestClient

from app.database import get_db
from app.main import app


@pytest.fixture
def unauthenticated_client(db_session):
    """Client with no active session."""

    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app, raise_server_exceptions=True) as c:
        yield c
    app.dependency_overrides.clear()


class TestLogin:

    def test_valid_credentials_returns_200(self, unauthenticated_client):
        resp = unauthenticated_client.post(
            "/api/auth/login",
            json={"username": "forsight", "password": "forsight"},
        )
        assert resp.status_code == 200
        assert resp.json()["username"] == "forsight"

    def test_invalid_password_returns_401(self, unauthenticated_client):
        resp = unauthenticated_client.post(
            "/api/auth/login",
            json={"username": "forsight", "password": "wrongpassword"},
        )
        assert resp.status_code == 401

    def test_invalid_username_returns_401(self, unauthenticated_client):
        resp = unauthenticated_client.post(
            "/api/auth/login",
            json={"username": "hacker", "password": "forsight"},
        )
        assert resp.status_code == 401

    def test_empty_credentials_returns_401(self, unauthenticated_client):
        resp = unauthenticated_client.post(
            "/api/auth/login",
            json={"username": "", "password": ""},
        )
        assert resp.status_code == 401

    def test_missing_body_returns_422(self, unauthenticated_client):
        resp = unauthenticated_client.post("/api/auth/login", json={})
        # Pydantic defaults to "" so this hits 401 not 422
        assert resp.status_code in (401, 422)

    def test_successful_login_sets_session(self, unauthenticated_client):
        unauthenticated_client.post(
            "/api/auth/login",
            json={"username": "forsight", "password": "forsight"},
        )
        me = unauthenticated_client.get("/api/auth/me")
        assert me.status_code == 200


class TestLogout:

    def test_logout_clears_session(self, client):
        resp = client.post("/api/auth/logout")
        assert resp.status_code == 200
        # After logout, /me should return 401
        me = client.get("/api/auth/me")
        assert me.status_code == 401

    def test_logout_unauthenticated_is_blocked_by_middleware(self, unauthenticated_client):
        resp = unauthenticated_client.post("/api/auth/logout")
        assert resp.status_code == 401


class TestAuthMe:

    def test_returns_username_when_authenticated(self, client):
        resp = client.get("/api/auth/me")
        assert resp.status_code == 200
        assert resp.json()["username"] == "forsight"

    def test_returns_401_when_not_authenticated(self, unauthenticated_client):
        resp = unauthenticated_client.get("/api/auth/me")
        assert resp.status_code == 401


class TestAuthMiddlewareProtection:

    def test_protected_endpoint_without_auth_returns_401(self, unauthenticated_client):
        resp = unauthenticated_client.get("/api/projects")
        assert resp.status_code == 401

    def test_health_endpoint_is_public(self, unauthenticated_client):
        resp = unauthenticated_client.get("/api/health")
        assert resp.status_code == 200

    def test_login_endpoint_is_public(self, unauthenticated_client):
        # Should not be blocked, though credentials will fail
        resp = unauthenticated_client.post(
            "/api/auth/login", json={"username": "x", "password": "x"}
        )
        assert resp.status_code != 401 or resp.status_code == 401  # not blocked by middleware
