"""Shared fixtures for ForSight test suite.

SQLite in-memory databases are per-connection. We use a single shared
connection for the entire test, so create_all and the test session see
the same tables. We monkey-patch app.database so internal code paths
(like run_runner_sync spawning a new SessionLocal) also hit the test DB.
"""

import os
import tempfile

import pytest
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

# ── bootstrap env before app import ──────────────────────────────────────────
_tmp = tempfile.mkdtemp()
os.environ.setdefault("FORSIGHT_DATA_DIR", _tmp)
os.environ.setdefault("FORSIGHT_SECRET_KEY", "test-secret-key-not-for-prod")

import app.database as _db_module
from app.models import Base
from app.database import get_db
from app.main import app


@pytest.fixture(scope="function")
def db_session():
    """
    Single SQLite in-memory connection, shared across all ORM operations
    within a test. We use connect_args and an event listener to force SQLAlchemy
    to reuse the same connection (important for :memory: databases).
    """
    from sqlalchemy import event

    # Create an engine with a shared, single connection
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
    )
    # Force SQLAlchemy to always use the SAME underlying connection
    conn = engine.connect()
    conn.begin()

    # Bind both Base.metadata and our Session to this exact connection
    Base.metadata.create_all(conn)

    TestingSession = sessionmaker(bind=conn, autocommit=False, autoflush=False)
    session = TestingSession()

    # Patch module-level references so internal app code also uses our session
    orig_engine = _db_module.engine
    orig_session_local = _db_module.SessionLocal
    _db_module.engine = engine
    _db_module.SessionLocal = TestingSession

    yield session

    session.close()
    _db_module.engine = orig_engine
    _db_module.SessionLocal = orig_session_local
    conn.rollback()
    conn.close()
    engine.dispose()


@pytest.fixture(scope="function")
def client(db_session):
    """FastAPI TestClient with DB override and pre-authenticated session."""

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db

    with TestClient(app, raise_server_exceptions=True) as c:
        c.post("/api/auth/login", json={"username": "forsight", "password": "forsight"})
        yield c

    app.dependency_overrides.clear()


@pytest.fixture
def project(client):
    resp = client.post("/api/projects", json={"name": "Test Engagement"})
    assert resp.status_code == 200, resp.text
    return resp.json()


@pytest.fixture
def project_with_targets(client, project):
    pid = project["id"]
    resp = client.post(
        f"/api/projects/{pid}/roe/paste",
        json={"content": "192.168.1.1\n10.0.0.1\nexample.com\ntest.example.com"},
    )
    assert resp.status_code == 200, resp.text
    return client.get(f"/api/projects/{pid}").json()
