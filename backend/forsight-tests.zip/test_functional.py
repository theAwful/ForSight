"""
Functional (end-to-end workflow) tests for ForSight.

These tests simulate the full user journey through the application:
  1. Create engagement → upload ROE → run through checklist phases
  2. Full pre-engagement gate workflow
  3. Job lifecycle
  4. Download all outputs
"""

import io
import pytest


class TestFullEngagementWorkflow:
    """Simulates a complete engagement from creation to checklist completion."""

    def test_create_and_configure_engagement(self, client):
        # 1. Create project
        resp = client.post("/api/projects", json={"name": "ACME Corp External"})
        assert resp.status_code == 200
        pid = resp.json()["id"]

        # 2. Upload ROE
        roe_content = b"10.0.0.1\n10.0.0.2\n10.0.0.3\nacme.com\nwww.acme.com"
        resp = client.post(
            f"/api/projects/{pid}/roe",
            files={"file": ("roe.txt", io.BytesIO(roe_content), "text/plain")},
        )
        assert resp.status_code == 200
        assert resp.json()["ips_count"] == 3
        assert resp.json()["domains_count"] == 2

        # 3. Verify targets accessible
        targets = client.get(f"/api/projects/{pid}/targets").json()
        assert "10.0.0.1" in targets["ips"]
        assert "acme.com" in targets["domains"]

        # 4. Mark pre-engagement complete
        client.patch(f"/api/projects/{pid}/checklist/roe_scope", params={"status": "completed"})
        client.patch(f"/api/projects/{pid}/checklist/roe_comm", params={"status": "completed"})

        # 5. Verify checklist shows completed
        checklist = client.get(f"/api/projects/{pid}/checklist").json()
        pre_phase = next(p for p in checklist if p["phase"] == "pre_engagement")
        for item in pre_phase["items"]:
            if item["id"] in ("roe_scope", "roe_comm"):
                assert item["status"] == "completed"

        # 6. Run a scan (whois doesn't need tools to be present to create a job)
        resp = client.post(f"/api/projects/{pid}/run/recon_whois")
        assert resp.status_code == 200
        job_id = resp.json()["id"]
        assert resp.json()["runner_key"] == "recon_whois"
        assert resp.json()["status"] == "pending"

        # 7. Check job is listed
        jobs = client.get(f"/api/projects/{pid}/jobs").json()
        assert any(j["id"] == job_id for j in jobs)

    def test_paste_roe_and_edit_targets(self, client):
        """User pastes ROE then edits individual targets."""
        resp = client.post("/api/projects", json={"name": "Edit Targets Test"})
        pid = resp.json()["id"]

        # Paste initial ROE
        client.post(
            f"/api/projects/{pid}/roe/paste",
            json={"content": "192.168.1.1\n192.168.1.2\nexample.com"},
        )

        # Edit targets
        client.put(
            f"/api/projects/{pid}/targets",
            json={"content": "10.10.10.1\nnewscope.com"},
        )

        targets = client.get(f"/api/projects/{pid}/targets").json()
        assert "10.10.10.1" in targets["ips"]
        assert "newscope.com" in targets["domains"]
        # Old targets replaced
        assert "192.168.1.1" not in targets["ips"]

    def test_checklist_notes_workflow(self, client):
        """Operator adds notes to checklist items."""
        resp = client.post("/api/projects", json={"name": "Notes Test"})
        pid = resp.json()["id"]

        # Add note to scope item
        client.patch(
            f"/api/projects/{pid}/checklist/roe_scope",
            params={"status": "completed", "notes": "Confirmed with ACME CSO via email on 2024-01-15"},
        )

        checklist = client.get(f"/api/projects/{pid}/checklist").json()
        pre = next(p for p in checklist if p["phase"] == "pre_engagement")
        scope_item = next(i for i in pre["items"] if i["id"] == "roe_scope")
        assert scope_item["notes"] == "Confirmed with ACME CSO via email on 2024-01-15"
        assert scope_item["status"] == "completed"

    def test_multiple_projects_isolated(self, client):
        """Two projects do not share targets or jobs."""
        p1 = client.post("/api/projects", json={"name": "Project Alpha"}).json()
        p2 = client.post("/api/projects", json={"name": "Project Beta"}).json()

        client.post(
            f"/api/projects/{p1['id']}/roe/paste",
            json={"content": "10.1.1.1\nalpha.com"},
        )
        client.post(
            f"/api/projects/{p2['id']}/roe/paste",
            json={"content": "10.2.2.2\nbeta.com"},
        )

        t1 = client.get(f"/api/projects/{p1['id']}/targets").json()
        t2 = client.get(f"/api/projects/{p2['id']}/targets").json()

        assert "10.1.1.1" in t1["ips"]
        assert "10.2.2.2" not in t1["ips"]
        assert "10.2.2.2" in t2["ips"]
        assert "10.1.1.1" not in t2["ips"]

    def test_delete_project_removes_jobs_and_checklist(self, client):
        """Deleting a project cascades to jobs and checklist statuses."""
        p = client.post("/api/projects", json={"name": "To Delete"}).json()
        pid = p["id"]

        # Complete pre-engagement and submit a job
        client.patch(f"/api/projects/{pid}/checklist/roe_scope", params={"status": "completed"})
        client.patch(f"/api/projects/{pid}/checklist/roe_comm", params={"status": "completed"})
        client.post(f"/api/projects/{pid}/roe/paste", json={"content": "10.0.0.1"})
        client.post(f"/api/projects/{pid}/run/recon_whois")

        # Delete
        resp = client.delete(f"/api/projects/{pid}")
        assert resp.status_code == 200

        # Project and jobs gone
        assert client.get(f"/api/projects/{pid}").status_code == 404
        assert client.get(f"/api/projects/{pid}/jobs").status_code == 404

    def test_download_outputs_404_before_any_scans(self, client, project):
        """Downloading results before any scans returns 404."""
        pid = project["id"]
        resp = client.get(f"/api/projects/{pid}/download")
        assert resp.status_code == 404


class TestPreEngagementGateWorkflow:
    """Full gate open/close workflow."""

    def test_gate_blocks_then_allows(self, client):
        p = client.post("/api/projects", json={"name": "Gate Test"}).json()
        pid = p["id"]
        client.post(f"/api/projects/{pid}/roe/paste", json={"content": "10.0.0.1"})

        # Both items unchecked — blocked
        assert client.post(f"/api/projects/{pid}/run/recon_whois").status_code == 403

        # Mark only first — still blocked
        client.patch(f"/api/projects/{pid}/checklist/roe_scope", params={"status": "completed"})
        assert client.post(f"/api/projects/{pid}/run/recon_whois").status_code == 403

        # Mark second — now allowed
        client.patch(f"/api/projects/{pid}/checklist/roe_comm", params={"status": "completed"})
        assert client.post(f"/api/projects/{pid}/run/recon_whois").status_code == 200

    def test_phase_run_respects_gate(self, client):
        p = client.post("/api/projects", json={"name": "Phase Gate"}).json()
        pid = p["id"]
        client.post(f"/api/projects/{pid}/roe/paste", json={"content": "10.0.0.1"})

        assert client.post(f"/api/projects/{pid}/run-phase/recon").status_code == 403

        client.patch(f"/api/projects/{pid}/checklist/roe_scope", params={"status": "completed"})
        client.patch(f"/api/projects/{pid}/checklist/roe_comm", params={"status": "completed"})
        resp = client.post(f"/api/projects/{pid}/run-phase/recon")
        assert resp.status_code == 200
        data = resp.json()
        assert "jobs" in data
        assert len(data["jobs"]) > 0


class TestFeedbackWorkflow:

    def test_submit_and_retrieve_feedback(self, client):
        # Submit feature request
        f1 = client.post(
            "/api/feedback",
            json={"kind": "feature", "title": "Dark mode", "description": "Night owl support"},
        ).json()
        # Submit bug
        f2 = client.post(
            "/api/feedback",
            json={"kind": "bug", "title": "Screenshot fails on 443"},
        ).json()

        # Retrieve all
        all_items = client.get("/api/feedback").json()
        all_ids = [i["id"] for i in all_items]
        assert f1["id"] in all_ids
        assert f2["id"] in all_ids

        # Filter features only
        features = client.get("/api/feedback?kind=feature").json()
        assert all(i["kind"] == "feature" for i in features)

        # Filter bugs only
        bugs = client.get("/api/feedback?kind=bug").json()
        assert all(i["kind"] == "bug" for i in bugs)
