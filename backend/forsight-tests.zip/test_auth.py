"""
Unit tests for app.auth — credential verification and password hashing.
"""

import pytest

from app.auth import verify_password, verify_credentials


class TestVerifyPassword:

    def test_correct_password(self):
        from passlib.context import CryptContext
        ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
        hashed = ctx.hash("mysecret")
        assert verify_password("mysecret", hashed) is True

    def test_wrong_password(self):
        from passlib.context import CryptContext
        ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
        hashed = ctx.hash("mysecret")
        assert verify_password("wrong", hashed) is False

    def test_empty_plain_returns_false(self):
        from passlib.context import CryptContext
        ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
        hashed = ctx.hash("mysecret")
        assert verify_password("", hashed) is False

    def test_empty_hash_returns_false(self):
        assert verify_password("password", "") is False

    def test_both_empty_returns_false(self):
        assert verify_password("", "") is False

    def test_invalid_hash_returns_false(self):
        # Should not crash, just return False
        assert verify_password("password", "notahash") is False


class TestVerifyCredentials:

    def test_correct_default_credentials(self):
        assert verify_credentials("forsight", "forsight") is True

    def test_case_insensitive_username(self):
        assert verify_credentials("FORSIGHT", "forsight") is True
        assert verify_credentials("ForSight", "forsight") is True

    def test_wrong_username(self):
        assert verify_credentials("admin", "forsight") is False

    def test_wrong_password(self):
        assert verify_credentials("forsight", "wrongpassword") is False

    def test_empty_username(self):
        assert verify_credentials("", "forsight") is False

    def test_empty_password(self):
        assert verify_credentials("forsight", "") is False

    def test_both_empty(self):
        assert verify_credentials("", "") is False

    def test_sql_injection_attempt(self):
        assert verify_credentials("admin'--", "forsight") is False

    def test_whitespace_username_stripped(self):
        # The login endpoint strips, but verify_credentials itself does the check
        assert verify_credentials("  forsight  ", "forsight") is True
