"""
Integration tests for feedback, roadmap, and hosts API endpoints.
"""

import pytest


class TestFeedback:

    def test_list_feedback_empty_initially(self, client):
        resp = client.get("/api/feedback")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_create_feature_request(self, client):
        resp = client.post(
            "/api/feedback",
            json={"kind": "feature", "title": "Add PDF export", "description": "Would be great"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["kind"] == "feature"
        assert data["title"] == "Add PDF export"
        assert "id" in data

    def test_create_bug_report(self, client):
        resp = client.post(
            "/api/feedback",
            json={"kind": "bug", "title": "Login fails on Firefox"},
        )
        assert resp.status_code == 200
        assert resp.json()["kind"] == "bug"

    def test_invalid_kind_returns_400(self, client):
        resp = client.post(
            "/api/feedback",
            json={"kind": "compliment", "title": "Great app"},
        )
        assert resp.status_code == 400

    def test_filter_by_kind_feature(self, client):
        client.post("/api/feedback", json={"kind": "feature", "title": "Feature 1"})
        client.post("/api/feedback", json={"kind": "bug", "title": "Bug 1"})
        resp = client.get("/api/feedback?kind=feature")
        assert resp.status_code == 200
        for item in resp.json():
            assert item["kind"] == "feature"

    def test_filter_by_kind_bug(self, client):
        client.post("/api/feedback", json={"kind": "feature", "title": "Feature 2"})
        client.post("/api/feedback", json={"kind": "bug", "title": "Bug 2"})
        resp = client.get("/api/feedback?kind=bug")
        assert resp.status_code == 200
        for item in resp.json():
            assert item["kind"] == "bug"

    def test_no_filter_returns_all(self, client):
        client.post("/api/feedback", json={"kind": "feature", "title": "F"})
        client.post("/api/feedback", json={"kind": "bug", "title": "B"})
        all_items = client.get("/api/feedback").json()
        kinds = {i["kind"] for i in all_items}
        assert "feature" in kinds
        assert "bug" in kinds

    def test_missing_title_returns_422(self, client):
        resp = client.post("/api/feedback", json={"kind": "feature"})
        assert resp.status_code == 422

    def test_feedback_has_created_at(self, client):
        resp = client.post(
            "/api/feedback",
            json={"kind": "feature", "title": "Timestamps"},
        )
        assert "created_at" in resp.json()

    def test_feedback_ordered_newest_first(self, client):
        f1 = client.post("/api/feedback", json={"kind": "feature", "title": "Older"}).json()
        f2 = client.post("/api/feedback", json={"kind": "bug", "title": "Newer"}).json()
        items = client.get("/api/feedback").json()
        ids = [i["id"] for i in items]
        assert ids.index(f2["id"]) < ids.index(f1["id"])


class TestRoadmap:

    def test_list_roadmap_returns_items(self, client):
        resp = client.get("/api/roadmap")
        assert resp.status_code == 200
        items = resp.json()
        assert isinstance(items, list)
        assert len(items) > 0

    def test_roadmap_items_have_required_fields(self, client):
        items = client.get("/api/roadmap").json()
        for item in items:
            assert "id" in item
            assert "title" in item
            assert "status" in item

    def test_roadmap_items_ordered_by_sort_order(self, client):
        items = client.get("/api/roadmap").json()
        orders = [i["sort_order"] for i in items]
        assert orders == sorted(orders)

    def test_roadmap_no_duplicate_titles(self, client):
        items = client.get("/api/roadmap").json()
        titles = [i["title"] for i in items]
        assert len(titles) == len(set(titles))

    def test_roadmap_seeded_on_first_call(self, client):
        """Second call should return same number of items (no duplicate seed)."""
        items1 = client.get("/api/roadmap").json()
        items2 = client.get("/api/roadmap").json()
        assert len(items1) == len(items2)


class TestHosts:

    def test_hosts_empty_before_nmap(self, client, project_with_targets):
        pid = project_with_targets["id"]
        resp = client.get(f"/api/projects/{pid}/hosts")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_hosts_nonexistent_project_404(self, client):
        resp = client.get("/api/projects/99999/hosts")
        assert resp.status_code == 404

    def test_exclude_host(self, client, project):
        pid = project["id"]
        resp = client.post(
            f"/api/projects/{pid}/hosts/exclude",
            json={"host": "192.168.1.1"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True

    def test_exclude_host_is_idempotent(self, client, project):
        pid = project["id"]
        client.post(f"/api/projects/{pid}/hosts/exclude", json={"host": "10.0.0.1"})
        resp = client.post(
            f"/api/projects/{pid}/hosts/exclude", json={"host": "10.0.0.1"}
        )
        assert resp.status_code == 200

    def test_exclude_empty_host_returns_400(self, client, project):
        pid = project["id"]
        resp = client.post(
            f"/api/projects/{pid}/hosts/exclude",
            json={"host": ""},
        )
        assert resp.status_code == 400

    def test_exclude_host_nonexistent_project_404(self, client):
        resp = client.post(
            "/api/projects/99999/hosts/exclude",
            json={"host": "10.0.0.1"},
        )
        assert resp.status_code == 404


class TestScreenshots:

    def test_list_screenshots_empty(self, client, project):
        pid = project["id"]
        resp = client.get(f"/api/projects/{pid}/screenshots")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_list_screenshots_nonexistent_project_404(self, client):
        resp = client.get("/api/projects/99999/screenshots")
        assert resp.status_code == 404

    def test_get_nonexistent_screenshot_404(self, client, project):
        pid = project["id"]
        resp = client.get(f"/api/projects/{pid}/screenshots/files/notafile.png")
        assert resp.status_code == 404


class TestJobOutput:

    def test_output_for_nonexistent_job_404(self, client, project):
        pid = project["id"]
        resp = client.get(f"/api/projects/{pid}/jobs/99999/output")
        assert resp.status_code == 404
