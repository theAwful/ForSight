# ForSight — Prometheus + Grafana Monitoring Setup
**Prometheus/Grafana server:** `172.22.50.23`

---

## Why the Nessus Tab is Slow — Root Cause

When you open the Nessus tab the frontend fires three API calls in `Promise.all` and waits
for **all three** before rendering anything:

```
Promise.all([
  api.nessus.listScans(projectId),       → GET /api/nessus/scans     → Tenable REST call  (~1–3s)
  api.nessus.listImports(projectId),     → DB query                  (~fast)
  api.nessus.templatesViaWeb(projectId)  → ← THIS IS THE BOTTLENECK
    .catch(() => api.nessus.templates()) → fallback also slow
])
```

`templatesViaWeb` calls `list_templates_via_web()` in `nessus_web_launch.py`, which on
**every single tab open**:

1. Spawns a headless Chrome via Selenium  
2. Navigates to your Nessus URL, waits up to 15s for the login page  
3. Types credentials, submits, waits for the SPA to load  
4. Clicks "New Scan", waits for the template picker to render  
5. Scrapes the list, quits the browser  

That's a full browser session — typically **10–30 seconds**. Since `Promise.all` blocks on
the slowest call, the entire tab is frozen until it finishes.

### Fix it now (one function, ~10 lines)

Templates almost never change between tab opens. Add a server-side TTL cache to
`backend/app/main.py`:

```python
import time as _time

_templates_web_cache: dict = {"data": None, "ts": 0.0}
_TEMPLATES_WEB_CACHE_TTL = 300  # 5 minutes

@app.get("/api/projects/{project_id}/nessus/templates-web")
def nessus_list_templates_via_web(project_id: int, db: Session = Depends(get_db)):
    now = _time.time()
    if (
        _templates_web_cache["data"] is not None
        and (now - _templates_web_cache["ts"]) < _TEMPLATES_WEB_CACHE_TTL
    ):
        from app.metrics import nessus_template_cache_hits
        nessus_template_cache_hits.inc()
        return {"templates": _templates_web_cache["data"]}

    from app.metrics import nessus_template_cache_misses
    nessus_template_cache_misses.inc()

    # ... existing Selenium code here (unchanged) ...

    _templates_web_cache["data"] = templates
    _templates_web_cache["ts"] = _time.time()
    return {"templates": templates}
```

First open still takes the Selenium hit. Every subsequent open within 5 minutes: **instant**.

---

## Step 1 — Instrument the ForSight Backend

### 1a. Install the library

```bash
cd backend
pip install prometheus-fastapi-instrumentator
echo "prometheus-fastapi-instrumentator>=6.1.0" >> requirements.txt
```

### 1b. Wire into FastAPI (`backend/app/main.py`)

Near the top, after existing imports:
```python
from prometheus_fastapi_instrumentator import Instrumentator
```

After `app = FastAPI(...)`:
```python
Instrumentator(
    should_group_status_codes=False,
    should_ignore_untemplated=True,
    should_respect_env_var=True,
    env_var_name="ENABLE_METRICS",
    excluded_handlers=["/metrics"],
).instrument(app).expose(app)
```

### 1c. Drop in `metrics.py`

Copy the provided `metrics.py` to `backend/app/metrics.py`.

### 1d. Instrument the slow paths

**`nessus_web_launch.py`** — wrap every public function:
```python
from app.metrics import time_selenium, nessus_selenium_errors

def list_templates_via_web(base_url, username, password, ...):
    with time_selenium("list_templates"):
        try:
            # ... existing code (unchanged) ...
        except NessusWebLaunchError as e:
            nessus_selenium_errors.labels(
                operation="list_templates", error_type=type(e).__name__
            ).inc()
            raise

def _login_and_go_to_my_scans(driver, ...):
    with time_selenium("login"):
        # ... existing code (unchanged) ...
```

**`tenable_client.py`** — wrap `_request()`:
```python
from app.metrics import time_nessus_api, nessus_api_errors

def _request(method, path, ...):
    operation = path.strip("/").split("/")[1] if "/" in path.strip("/") else path
    with time_nessus_api(operation):
        try:
            resp = requests.request(...)
            if not resp.ok:
                nessus_api_errors.labels(
                    operation=operation, status_code=str(resp.status_code)
                ).inc()
            return resp
        except Exception as e:
            nessus_api_errors.labels(operation=operation, status_code="network_error").inc()
            raise
```

**`main.py`** — auth counters:
```python
from app.metrics import auth_login_total

# Inside your login route, after credential check:
auth_login_total.labels(result="success").inc()  # or "failure"
```

### 1e. Enable metrics in your environment

In `.env` (or `deploy/environment.example` → `/etc/forsight/environment`):
```bash
ENABLE_METRICS=true
```

In Docker (`docker-compose.yml`):
```yaml
services:
  backend:
    environment:
      - ENABLE_METRICS=true
```

### 1f. Verify the endpoint is live

```bash
# From the ForSight host, or any machine that can reach it:
curl http://<FORSIGHT_HOST>:8000/metrics | head -30
```

You should see lines like:
```
# HELP http_requests_total Total number of requests by method, status and handler.
forsight_nessus_selenium_duration_seconds_bucket{...} 0.0
```

---

## Step 2 — Configure Prometheus on 172.22.50.23

### 2a. Find your Prometheus config

```bash
# SSH into the lab server
ssh user@172.22.50.23

# Find the config file
docker ps                          # if running in Docker
docker inspect <prometheus-name> | grep prometheus.yml
# or
ps aux | grep prometheus           # if running as a process
```

Common locations:
- Docker volume: `docker exec <container> cat /etc/prometheus/prometheus.yml`
- Bare metal: `/etc/prometheus/prometheus.yml`

### 2b. Add the ForSight scrape job

Add the following block to the `scrape_configs:` section of `prometheus.yml`
(replace `FORSIGHT_HOST` with the actual IP of your ForSight machine):

```yaml
  - job_name: forsight_backend
    scrape_interval: 15s
    scrape_timeout: 10s
    metrics_path: /metrics
    static_configs:
      - targets:
          - FORSIGHT_HOST:8000    # e.g. 172.22.50.45:8000
        labels:
          environment: production
          instance: forsight-prod
```

### 2c. Add the alert rules

Copy `alerts.yml` to the Prometheus server and reference it in `prometheus.yml`:

```bash
# From your machine
scp alerts.yml user@172.22.50.23:/etc/prometheus/forsight_alerts.yml
```

In `prometheus.yml`:
```yaml
rule_files:
  - "/etc/prometheus/forsight_alerts.yml"
```

If running in Docker, add to the volume mount:
```yaml
volumes:
  - ./alerts.yml:/etc/prometheus/forsight_alerts.yml:ro
```

### 2d. Reload Prometheus (no restart needed)

```bash
# On 172.22.50.23
curl -X POST http://localhost:9090/-/reload

# Verify the new job appeared
curl http://localhost:9090/api/v1/targets | python3 -m json.tool | grep -A5 "forsight"
```

### 2e. Verify scraping is working

Open `http://172.22.50.23:9090` → **Status → Targets**  
You should see `forsight_backend` with state **UP**.

Test a query in the expression browser:
```promql
forsight_nessus_selenium_duration_seconds_count
```

---

## Step 3 — Grafana Dashboard on 172.22.50.23

### 3a. Add Prometheus as a data source (if not already done)

Grafana UI → **Connections → Data Sources → Add** → Prometheus  
URL: `http://localhost:9090` (or `http://172.22.50.23:9090` from remote)

### 3b. Create the ForSight dashboard

**Grafana → Dashboards → New → Import**  
Or build it manually — here are the key panels with exact PromQL:

---

#### Row 1: Health Overview

| Panel | Type | Query |
|---|---|---|
| Backend Status | Stat | `up{job="forsight_backend"}` |
| Request Rate | Stat | `sum(rate(http_requests_total{job="forsight_backend"}[5m]))` |
| Error Rate | Stat | `sum(rate(http_requests_total{job="forsight_backend",status=~"5.."}[5m]))` |
| Active Scan Jobs | Stat | `sum(forsight_scan_jobs_active)` |

---

#### Row 2: Nessus Tab Performance (the slow tab)

| Panel | Type | Query | Why it matters |
|---|---|---|---|
| Selenium p95 Latency | Time series | `histogram_quantile(0.95, rate(forsight_nessus_selenium_duration_seconds_bucket[10m]))` | Direct measure of tab load pain |
| Selenium p50 Latency | Time series | `histogram_quantile(0.50, rate(forsight_nessus_selenium_duration_seconds_bucket[10m]))` | Typical user experience |
| Template Cache Hit Rate | Stat | `rate(forsight_nessus_template_cache_hits_total[5m]) / (rate(forsight_nessus_template_cache_hits_total[5m]) + rate(forsight_nessus_template_cache_misses_total[5m]))` | Should be >80% after fix |
| Tenable API p99 | Time series | `histogram_quantile(0.99, rate(forsight_nessus_api_duration_seconds_bucket[10m]))` | Nessus cloud/on-prem latency |
| Tenable API Errors | Time series | `rate(forsight_nessus_api_errors_total[5m])` | Break down by `status_code` |
| Selenium Errors | Stat | `increase(forsight_nessus_selenium_errors_total[1h])` | Any non-zero = investigate |

---

#### Row 3: Scan Jobs (tool runners)

| Panel | Type | Query |
|---|---|---|
| Active Jobs by Tool | Time series | `forsight_scan_jobs_active` (legend: `{{runner_key}}`) |
| Job Completion Rate | Time series | `rate(forsight_scan_jobs_total{status="completed"}[10m])` by `runner_key` |
| Job Failure Rate | Time series | `rate(forsight_scan_jobs_total{status="failed"}[10m])` by `runner_key` |
| Job Duration p95 | Heatmap | `forsight_scan_job_duration_seconds_bucket` |
| Most Used Tools | Bar chart | `sum by(runner_key)(forsight_scan_jobs_total{status="completed"})` |

---

#### Row 4: API Performance

| Panel | Type | Query |
|---|---|---|
| p99 Latency by Endpoint | Time series | `histogram_quantile(0.99, sum by(handler,le)(rate(http_request_duration_seconds_bucket[5m])))` |
| Top 10 Slowest Endpoints | Table | `topk(10, histogram_quantile(0.95, sum by(handler,le)(rate(http_request_duration_seconds_bucket[5m]))))` |
| 4xx Rate by Endpoint | Time series | `rate(http_requests_total{status=~"4.."}[5m])` by `handler` |

---

#### Row 5: Auth & Security

| Panel | Type | Query |
|---|---|---|
| Login Success/Failure | Time series | `rate(forsight_auth_login_total[5m])` by `result` |
| Failed Login Rate | Stat | `rate(forsight_auth_login_total{result="failure"}[5m])` — red if > 1/min |

---

## Step 4 — Network Considerations

Since ForSight is on one machine and Prometheus is on `172.22.50.23`, Prometheus needs to
**reach ForSight's port 8000 inbound**. Check:

```bash
# On the ForSight host — is 8000 reachable from the lab network?
# If running in Docker, the port needs to be exposed in docker-compose.yml:
ports:
  - "8000:8000"   # or bind to specific interface: "0.0.0.0:8000:8000"

# From 172.22.50.23, test reachability:
curl http://FORSIGHT_HOST:8000/metrics | head -5
```

If ForSight is behind nginx with no direct port 8000 exposure, either:
- Open port 8000 for Prometheus scraping only (firewall rule: source `172.22.50.23/32`)
- Or add a `/metrics` location block to your nginx config that proxies to the backend

---

## Alert Routing (Optional)

If you want alerts to go somewhere beyond Grafana visual alerts, add to `prometheus.yml`:

```yaml
alerting:
  alertmanagers:
    - static_configs:
        - targets:
            - localhost:9093   # if Alertmanager is running on 172.22.50.23
```

Common Alertmanager receivers for a pentest lab: Slack webhook, email, or PagerDuty.

---

## Quick-Start Checklist

**On the ForSight host:**
- [ ] `pip install prometheus-fastapi-instrumentator`
- [ ] Add `Instrumentator(...).instrument(app).expose(app)` to `main.py`
- [ ] Copy `metrics.py` → `backend/app/metrics.py`
- [ ] Add TTL cache to `templates-web` endpoint
- [ ] Instrument `nessus_web_launch.py` with `time_selenium()`
- [ ] Instrument `tenable_client.py` `_request()` with `time_nessus_api()`
- [ ] Set `ENABLE_METRICS=true` in environment
- [ ] Verify `curl http://FORSIGHT_HOST:8000/metrics` returns metric lines
- [ ] Verify port 8000 is reachable from `172.22.50.23`

**On `172.22.50.23`:**
- [ ] Add ForSight scrape job to `prometheus.yml` with correct `FORSIGHT_HOST:8000`
- [ ] Copy `alerts.yml` to Prometheus server, add to `rule_files`
- [ ] `curl -X POST http://localhost:9090/-/reload`
- [ ] Confirm target is **UP** in `http://172.22.50.23:9090/` → Status → Targets
- [ ] Add Prometheus data source in Grafana if not already present
- [ ] Build the dashboard panels from the queries above
