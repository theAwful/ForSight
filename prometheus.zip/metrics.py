"""
ForSight — Prometheus custom metrics
Drop this file into backend/app/metrics.py
"""
import time
from prometheus_client import Counter, Histogram, Gauge, Summary

# ── Nessus / Selenium ─────────────────────────────────────────────────────────

nessus_selenium_duration = Histogram(
    "forsight_nessus_selenium_duration_seconds",
    "Time spent in Selenium-driven Nessus operations",
    ["operation"],
    buckets=[1, 2, 5, 10, 20, 30, 60],
)

nessus_api_duration = Histogram(
    "forsight_nessus_api_duration_seconds",
    "Time for Tenable REST API calls",
    ["operation"],
    buckets=[0.1, 0.5, 1, 2, 5, 10, 30],
)

nessus_api_errors = Counter(
    "forsight_nessus_api_errors_total",
    "Tenable API errors by operation and HTTP status",
    ["operation", "status_code"],
)

nessus_selenium_errors = Counter(
    "forsight_nessus_selenium_errors_total",
    "Selenium-driven Nessus errors by operation and error type",
    ["operation", "error_type"],
)

nessus_template_cache_hits = Counter(
    "forsight_nessus_template_cache_hits_total",
    "Template list served from cache (Selenium avoided)",
)

nessus_template_cache_misses = Counter(
    "forsight_nessus_template_cache_misses_total",
    "Template list required a fresh Selenium fetch",
)

# ── Scan Jobs ─────────────────────────────────────────────────────────────────

scan_job_duration = Histogram(
    "forsight_scan_job_duration_seconds",
    "Duration of tool runner scan jobs from submission to completion",
    ["runner_key"],
    buckets=[1, 5, 10, 30, 60, 120, 300, 600],
)

scan_job_total = Counter(
    "forsight_scan_jobs_total",
    "Total scan jobs submitted",
    ["runner_key", "status"],  # status: started | completed | failed
)

scan_jobs_active = Gauge(
    "forsight_scan_jobs_active",
    "Currently running scan jobs",
    ["runner_key"],
)

# ── Projects ─────────────────────────────────────────────────────────────────

projects_total = Gauge(
    "forsight_projects_total",
    "Total number of projects in the database",
)

# ── Auth ─────────────────────────────────────────────────────────────────────

auth_login_total = Counter(
    "forsight_auth_login_total",
    "Login attempts by result",
    ["result"],  # success | failure
)

# ── API latency summary for known-slow endpoints ──────────────────────────────

slow_endpoint_summary = Summary(
    "forsight_endpoint_latency_seconds",
    "Latency for monitored endpoints",
    ["endpoint"],
)


# ── Timing context managers ───────────────────────────────────────────────────

class _Timer:
    """Context manager that records elapsed time into a Histogram."""
    def __init__(self, histogram: Histogram, labels: dict):
        self._h = histogram
        self._labels = labels
        self._start: float = 0.0

    def __enter__(self) -> "_Timer":
        self._start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        elapsed = time.perf_counter() - self._start
        self._h.labels(**self._labels).observe(elapsed)
        # Don't suppress exceptions
        return None


def time_selenium(operation: str) -> _Timer:
    """Usage:  with time_selenium("list_templates"): ..."""
    return _Timer(nessus_selenium_duration, {"operation": operation})


def time_nessus_api(operation: str) -> _Timer:
    """Usage:  with time_nessus_api("list_scans"): ..."""
    return _Timer(nessus_api_duration, {"operation": operation})


def time_scan_job(runner_key: str) -> _Timer:
    """Usage:  with time_scan_job("nmap"): ..."""
    return _Timer(scan_job_duration, {"runner_key": runner_key})
